<?php
$filterTbls = array('bl_players', 'bl_teams');
